
export const DASHBOARD_DATA = 'DASHBOARD_DATA';

