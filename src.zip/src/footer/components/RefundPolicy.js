import React from 'react'
import Footer from "../../entertainment/modules/Footer"

function RefundPolicy() {
    return (
        <>
        <div>
         <h1 style={{ textAlign: "center", margin: "20px 0px" }}>AmVirgin Refund Policy</h1>   
        </div>
        <Footer/>
        </>
    )
}

export default RefundPolicy
