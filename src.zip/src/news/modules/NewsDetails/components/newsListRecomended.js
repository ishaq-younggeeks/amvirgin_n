import React from "react";

class NewsListRecomended extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <div class="container trendingpost blogsection">
        <h4 class="stories">  Recommended Videoes </h4>
        <hr/>
        <div class="slick-carousel slidermultinews">
          <a href="playvideo.html" class="videolink ">
            <div class="containerimage multiplayvideo">
              <img src="img/sunset.jpg" class="bannermulti"/> 
              <img class="videoplaybtn" src="img/playred.png" />
            </div> 
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a>
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/news1.webp" class="bannermulti"/>
              <img class="videoplaybtn" src="img/playred.png" />
            </div>
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a>
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/news1.jpg" class="bannermulti"/>
              <img class="videoplaybtn" src="img/playred.png" />
            </div> 
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a> 
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/news2.webp" class="bannermulti"/> 
              <img class="videoplaybtn" src="img/playred.png" />
            </div>
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a>
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/sunset.jpg" class="bannermulti"/>
              <img class="videoplaybtn" src="img/playred.png" />
            </div> 
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a>
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/news1.webp" class="bannermulti"/>
              <img class="videoplaybtn" src="img/playred.png" />
            </div>
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a>
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/news1.jpg" class="bannermulti"/>
              <img class="videoplaybtn" src="img/playred.png" />
            </div> 
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a> 
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/news2.webp" class="bannermulti"/>  
              <img class="videoplaybtn" src="img/playred.png" />
            </div>
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a>
        </div>
      </div>
    )
  }
}
export default NewsListRecomended;