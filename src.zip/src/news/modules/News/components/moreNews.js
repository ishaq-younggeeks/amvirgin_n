import React from "react";

class MoreNews extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <div class="specific newsvideoslider">
        <h3 class="videonews"> More</h3>
        <hr/>
        <div class="slick-carousel slidermultinews">
          <a href="playvideo.html" class="videolink ">
            <div class="containerimage multiplayvideo">
              <img src="img/sunset.jpg" class="bannermulti"/> 
              <img class="videoplaybtn" src="img/playred.png" />
            </div> 
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a>
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/news1.webp" class="bannermulti"/>
              <img class="videoplaybtn" src="img/playred.png" />
            </div>
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a>
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/news1.webp" class="bannermulti"/>
              <img class="videoplaybtn" src="img/playred.png" />
            </div> 
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a> 
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/news1.webp" class="bannermulti"/> 
              <img class="videoplaybtn" src="img/playred.png" />
            </div>
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a>
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/sunset.jpg" class="bannermulti"/>
              <img class="videoplaybtn" src="img/playred.png" />
            </div> 
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a>
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/news1.webp" class="bannermulti"/>
              <img class="videoplaybtn" src="img/playred.png" />
            </div>
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a>
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/news1.webp" class="bannermulti"/>
              <img class="videoplaybtn" src="img/playred.png" />
            </div> 
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a> 
          <a href="playvideo.html" class="videolink">
            <div class="containerimage multiplayvideo">
              <img src="img/news1.webp" class="bannermulti"/>  
              <img class="videoplaybtn" src="img/playred.png" />
            </div>
            <h4>A Day at the NRC and CAA Protests in Delhi</h4>
            <h6> 04:35 min </h6>
          </a>
        </div>
      </div>
    )
  }
}
export default MoreNews;