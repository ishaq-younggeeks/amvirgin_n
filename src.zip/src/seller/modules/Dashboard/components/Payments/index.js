import {connect} from 'react-redux';
import PaymentHome from './PaymentHome';


const mapStateToProps = state => {
    return {

    }
}

const mapDispatchToProps = dispatch => {
    return ({

    })
}

export default connect(mapStateToProps,mapDispatchToProps)(PaymentHome);
