
export const ADDRESS_DETAIL = 'ADDRESS_DETAIL';


