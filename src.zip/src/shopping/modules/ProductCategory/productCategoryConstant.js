// export const PRODUCT_DATA = 'PRODUCT_DATA';
// export const FETCHING = 'FETCHING';

export const IS_TOGGLE = "IS_TOGGLE";