export const DATA_RECEIVED = 'DATA_RECEIVED';
export const FETCHING = 'FETCHING';
export const PRODUCT_DATA = 'PRODUCT_DATA';
export const VIEW_PRODUCT = "VIEW_PRODUCT";
export const HOME_DATA = "HOME_DATA";
export const ALL_DEALS = "ALL_DEALS";
