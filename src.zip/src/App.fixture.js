import App from './App';

export default {
  component: App
};
