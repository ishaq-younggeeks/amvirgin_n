$("#bzoom").zoom({
    zoom_area_width: 400,
    autoplay_interval :3000,
    small_thumbs : 4,
    autoplay : false
  });